# IEM Lab v1 — Android source project

A native Kotlin Android app for repeatable **near-field** IEM response experiments using the phone's built-in microphone. Includes left/right stepped-tone measurement, optional microphone calibration CSV, in-session reference storage, and Wavelet GraphicEQ export.

## Measurement honesty and limitations

- This is **not** an IEC 60318-4 coupler, ear simulator, or eardrum-response measurement.
- The phone microphone is placed about 1–2 cm from the earphone nozzle. The output is an uncalibrated near-field response unless a microphone correction file is imported.
- A microphone calibration curve does not correct nozzle placement, acoustic loading, room reflections, leakage, or the absence of a defined ear simulator.
- Android devices may apply AGC, noise suppression, echo cancellation, resampling, or route-dependent processing. The app requests `UNPROCESSED` input where Android supports it, but cannot guarantee the signal path is unprocessed.
- The sweep covers approximately 100 Hz–10 kHz, with 1/6-octave-spaced tone points and two captures per point. Treat readings as comparative, not laboratory-grade.
- Keep playback volume moderate. Stop if a tone is uncomfortable. Do not wear the IEM while running high-level test tones.

## Build the APK using only your phone and GitHub

This project intentionally uses GitHub Actions to build the APK in the cloud. A Gradle wrapper JAR is not included; the workflow installs pinned Gradle 8.10.2 using the official Gradle setup action. This keeps the phone-uploadable source package smaller and avoids shipping an unverified wrapper binary.

1. Download and extract `IEM-Lab-v1-source.zip` on your phone.
2. Open GitHub in your mobile browser and create a new repository named `IEM-Lab` (Public or Private).
3. In the repository, choose **Add file → Upload files**. Upload the extracted project contents (not the ZIP itself), including the hidden `.github` folder. If GitHub mobile hides dot-folders, use the browser's desktop-site option or create `.github/workflows/android.yml` through **Add file → Create new file**.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build IEM Lab APK** and tap **Run workflow**. A push to `main` also starts a build.
6. Wait for the run to finish successfully. Open the completed run and download the artifact named **IEM-Lab-debug-APK**.
7. Extract the downloaded artifact ZIP. Install `app-debug.apk`. Android may ask you to allow installs from the browser or file manager you used.

## Calibration CSV

Use a UTF-8 text/CSV file with two columns and no units in the cells:

```csv
frequency_hz,correction_db
100,-0.8
200,-0.4
1000,0.0
5000,1.1
10000,1.8
```

Correction is interpolated logarithmically between calibration points. Frequencies outside the calibration range are not extrapolated. Values are added to measured levels.

## Wavelet export

The exporter uses the fixed 127-frequency grid documented by Wavelet (20 Hz through 19,871 Hz). It creates a GraphicEQ line and a preamp line. The gains are a capped inverse of the measured curve after optional microphone calibration, not a target-based AutoEQ profile. A reliable target response and a suitable acoustic coupler are needed for defensible correction.

In Wavelet: open **AutoEq → Import**, then choose the saved `.txt` file. Wavelet's format requirements are documented at <https://github.com/Pittvandewitt/Wavelet/blob/master/docs/Import.md>.

## Source layout

- `app/src/main/java/com/iemlab/MeasurementEngine.kt` — tone playback and microphone capture
- `Dsp.kt` — Goertzel tone-level estimator and frequency points
- `Calibration.kt` — validated calibration CSV parser and log interpolation
- `WaveletExporter.kt` — fixed Wavelet grid and GraphicEQ writer
- `MainActivity.kt` — native Android interface
- `.github/workflows/android.yml` — cloud APK build

## Build compatibility

The workflow uses JDK 17, Gradle 8.10.2, Android Gradle Plugin 8.8.2, Kotlin 2.0.21, and compile SDK 35. These are pinned for reproducibility, but Android SDK package availability and upstream action versions can change.
