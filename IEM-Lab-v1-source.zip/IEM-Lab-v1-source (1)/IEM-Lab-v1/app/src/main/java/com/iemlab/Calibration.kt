package com.iemlab

import kotlin.math.ln

data class CalPoint(val hz: Double, val db: Double)

class Calibration(points: List<CalPoint>) {
    private val points = points.sortedBy { it.hz }

    init {
        require(this.points.size >= 2) { "Calibration needs at least two points." }
        require(this.points.all { it.hz > 0.0 && it.hz.isFinite() && it.db.isFinite() }) {
            "Calibration contains invalid values."
        }
        require(this.points.zipWithNext().all { it.first.hz < it.second.hz }) {
            "Calibration frequencies must be unique."
        }
    }

    fun correctionAt(hz: Double): Double {
        require(hz >= points.first().hz && hz <= points.last().hz) {
            "No calibration value at ${hz.toInt()} Hz; extrapolation is disabled."
        }
        val upper = points.indexOfFirst { it.hz >= hz }
        if (upper <= 0) return points.first().db
        val a = points[upper - 1]
        val b = points[upper]
        val t = (ln(hz) - ln(a.hz)) / (ln(b.hz) - ln(a.hz))
        return a.db + (b.db - a.db) * t
    }

    companion object {
        fun parse(csv: String): Calibration {
            val rows = csv.lineSequence()
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") && !it.startsWith("frequency", true) }
            val points = rows.map { line ->
                val p = line.split(',', ';', '\t').map { it.trim() }
                require(p.size >= 2) { "Expected frequency_hz,correction_db" }
                CalPoint(p[0].toDouble(), p[1].toDouble())
            }.toList()
            return Calibration(points)
        }
    }
}
