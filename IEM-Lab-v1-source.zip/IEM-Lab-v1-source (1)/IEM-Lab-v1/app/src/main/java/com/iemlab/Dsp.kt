package com.iemlab

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt

object Dsp {
    fun goertzelDb(samples: ShortArray, count: Int, sampleRate: Int, frequency: Double): Double {
        val n = count.coerceAtMost(samples.size)
        if (n < 256) return Double.NaN
        val k = (0.5 + n * frequency / sampleRate).toInt()
        val omega = 2.0 * PI * k / n
        val coeff = 2.0 * cos(omega)
        var q1 = 0.0
        var q2 = 0.0
        var sumWindow = 0.0
        for (i in 0 until n) {
            val window = 0.5 - 0.5 * cos(2.0 * PI * i / (n - 1))
            val x = samples[i].toDouble() / 32768.0 * window
            val q0 = coeff * q1 - q2 + x
            q2 = q1
            q1 = q0
            sumWindow += window
        }
        val power = q1 * q1 + q2 * q2 - coeff * q1 * q2
        val amplitude = 2.0 * sqrt(power.coerceAtLeast(0.0)) / sumWindow.coerceAtLeast(1.0)
        return 20.0 * kotlin.math.log10(amplitude.coerceAtLeast(1e-9))
    }

    fun octaveFrequencies(): List<Double> {
        val result = mutableListOf<Double>()
        var f = 100.0
        while (f <= 10000.0) {
            result += f
            f *= 2.0.pow(1.0 / 6.0)
        }
        return result
    }

    private fun Double.pow(p: Double) = kotlin.math.exp(ln(this) * p)

    fun interpolateLog(points: List<CalPoint>, hz: Double): Double {
        if (points.isEmpty()) return 0.0
        if (hz <= points.first().hz) return points.first().db
        if (hz >= points.last().hz) return points.last().db
        val i = points.indexOfFirst { it.hz >= hz }
        val a = points[i - 1]
        val b = points[i]
        val t = (ln(hz) - ln(a.hz)) / (ln(b.hz) - ln(a.hz))
        return a.db + (b.db - a.db) * t
    }
}
