package com.iemlab

import android.Manifest
import androidx.activity.ComponentActivity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val points = mutableListOf<MeasurementPoint>()
    private var calibration: Calibration? = null
    private var reference: Map<String, Double>? = null
    private lateinit var status: TextView
    private lateinit var results: TextView
    private lateinit var runButton: Button
    private var selectedChannel = "L"
    private var exportMode = "Average"
    private val requestPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startMeasurement() else status.text = "Microphone permission is required for measurements."
    }
    private val openCalibration = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    val text = BufferedReader(InputStreamReader(input)).readText()
                    calibration = Calibration.parse(text)
                }
                status.text = "Calibration loaded. Corrections are applied only inside its frequency range."
            } catch (e: Exception) {
                status.text = "Calibration import failed: ${e.message}"
            }
        }
    }
    private val saveExport = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            try {
                val text = buildExport()
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                status.text = "Wavelet GraphicEQ saved."
            } catch (e: Exception) {
                status.text = "Export failed: ${e.message}"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 32)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        fun text(value: String, size: Float = 15f, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = value
                textSize = size
                setTextColor(0xFF17212B.toInt())
                if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            }
        fun button(label: String, action: () -> Unit): Button =
            Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { action() }
            }

        root.addView(text("IEM Lab", 28f, true))
        root.addView(text("Near-field IEM response • Android v1", 14f))
        root.addView(text(
            "IMPORTANT: This app measures the phone microphone near the earphone nozzle. " +
            "It is not an IEC 60318-4 coupler or an eardrum-response measurement. " +
            "Placement, room reflections, mic processing and AGC affect results.", 14f
        ))
        root.addView(text("Measurement", 20f, true))
        val channelRow = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val left = RadioButton(this).apply { text = "Left channel"; id = View.generateViewId(); isChecked = true }
        val right = RadioButton(this).apply { text = "Right channel"; id = View.generateViewId() }
        channelRow.addView(left); channelRow.addView(right)
        channelRow.setOnCheckedChangeListener { _, checked -> selectedChannel = if (checked == left.id) "L" else "R" }
        root.addView(channelRow)
        root.addView(text("Place the built-in phone microphone 1–2 cm from the active earphone nozzle. Keep distance and angle consistent. Use a quiet room and moderate listening volume.", 14f))
        runButton = button("Measure selected channel") { checkPermissionAndRun() }
        root.addView(runButton)
        root.addView(button("Measure left, then right") {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermission.launch(Manifest.permission.RECORD_AUDIO)
                status.text = "Grant microphone permission, then tap this button again."
            } else {
                runBoth()
            }
        })
        root.addView(button("Set current measurements as session reference") {
            val avg = averagedPoints()
            if (avg.isEmpty()) status.text = "Measure a channel first."
            else {
                reference = avg.associate { it.hz.toString() to it.db }
                status.text = "Session reference stored. New measurements will show their dB difference from this reference."
                updateResults()
            }
        })
        root.addView(text("Calibration", 20f, true))
        root.addView(text("Optional CSV format: frequency_hz,correction_db. Example: 100,-1.2. Calibration is interpolated on a log-frequency axis; no extrapolation is performed.", 14f))
        root.addView(button("Import microphone calibration CSV") {
            openCalibration.launch(arrayOf("text/*", "text/csv", "application/octet-stream"))
        })
        root.addView(text("Wavelet export", 20f, true))
        root.addView(text("Choose which measured channel is used for the export:", 14f))
        val exportGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("Average", "Left", "Right").forEach { mode ->
            val rb = RadioButton(this).apply {
                text = mode
                id = View.generateViewId()
                isChecked = mode == "Average"
                tag = mode
            }
            exportGroup.addView(rb)
        }
        exportGroup.setOnCheckedChangeListener { group, checkedId ->
            exportMode = group.findViewById<RadioButton>(checkedId)?.tag as? String ?: "Average"
        }
        root.addView(exportGroup)
        root.addView(text("Exports Wavelet's fixed 127-frequency GraphicEQ grid. The curve is a capped inverse of the measured response, not a validated target or guaranteed correction. Verify at safe volume.", 14f))
        root.addView(button("Save Wavelet GraphicEQ (.txt)") {
            if (points.isEmpty()) status.text = "Measure at least one channel first."
            else saveExport.launch("IEM-Lab-Wavelet-GraphicEQ.txt")
        })
        root.addView(button("Copy Wavelet GraphicEQ") {
            try {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("GraphicEQ", buildExport()))
                status.text = "GraphicEQ copied. In Wavelet AutoEq, choose Import and select a .txt file; clipboard alone is not a file."
            } catch (e: Exception) { status.text = "Copy failed: ${e.message}" }
        })
        root.addView(text("Status", 20f, true))
        status = text("Ready. Connect your IEM and select a channel.", 14f)
        root.addView(status)
        root.addView(text("Results", 20f, true))
        results = text("No measurements yet.", 13f)
        root.addView(results)
    }

    private fun checkPermissionAndRun() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermission.launch(Manifest.permission.RECORD_AUDIO)
        } else startMeasurement()
    }

    private fun startMeasurement() {
        val channel = selectedChannel
        runButton.isEnabled = false
        status.text = "Measuring $channel. Keep the phone and earphone still."
        executor.execute {
            try {
                MeasurementEngine(this).runChannel(channel) { p ->
                    synchronized(points) { points.removeAll { it.channel == p.channel && it.hz == p.hz && it.run == p.run }; points.add(p) }
                    runOnUiThread {
                        status.text = "Measuring $channel: ${p.hz.toInt()} Hz • repeat ${p.run}/2"
                        updateResults()
                    }
                }
                runOnUiThread {
                    runButton.isEnabled = true
                    status.text = "$channel measurement complete. Results are relative near-field levels."
                    updateResults()
                }
            } catch (e: Exception) {
                runOnUiThread { runButton.isEnabled = true; status.text = "Measurement error: ${e.message}. Check audio routing and microphone permission." }
            }
        }
    }

    private fun runBoth() {
        runButton.isEnabled = false
        status.text = "Measuring left channel first. Keep the microphone at the nozzle."
        executor.execute {
            try {
                val engine = MeasurementEngine(this)
                listOf("L", "R").forEach { ch ->
                    engine.runChannel(ch) { p ->
                        synchronized(points) { points.removeAll { it.channel == p.channel && it.hz == p.hz && it.run == p.run }; points.add(p) }
                        runOnUiThread { status.text = "Measuring $ch: ${p.hz.toInt()} Hz • repeat ${p.run}/2"; updateResults() }
                    }
                }
                runOnUiThread { runButton.isEnabled = true; status.text = "Left and right measurements complete."; updateResults() }
            } catch (e: Exception) {
                runOnUiThread { runButton.isEnabled = true; status.text = "Measurement error: ${e.message}" }
            }
        }
    }

    private fun averagedPoints(channel: String? = null): List<CalPoint> {
        val snapshot = synchronized(points) { points.toList() }
        return snapshot.filter { channel == null || it.channel == channel }
            .groupBy { it.hz }
            .map { (hz, samples) ->
                var db = samples.map { it.db }.filter { it.isFinite() }.average()
                val cal = calibration
                if (cal != null) {
                    try { db += cal.correctionAt(hz) } catch (_: Exception) {}
                }
                CalPoint(hz, db)
            }.sortedBy { it.hz }
    }

    private fun updateResults() {
        val l = averagedPoints("L")
        val r = averagedPoints("R")
        val all = buildString {
            append("Sample rate: 48 kHz requested (device may route/resample differently).\\n")
            append("Points measured: L=${l.size}, R=${r.size}\\n")
            if (l.isNotEmpty()) append("\\nLEFT (Hz : dBFS-relative)\\n" + l.joinToString("\\n") { "${it.hz.toInt()} : ${"%.1f".format(Locale.US, it.db)}" })
            if (r.isNotEmpty()) append("\\n\\nRIGHT (Hz : dBFS-relative)\\n" + r.joinToString("\\n") { "${it.hz.toInt()} : ${"%.1f".format(Locale.US, it.db)}" })
            reference?.let { ref ->
                val current = (l + r).groupBy { it.hz }.mapValues { (_, v) -> v.map { it.db }.average() }
                val deltas = current.mapNotNull { (hz, db) -> ref[hz.toString()]?.let { hz to (db - it) } }.sortedBy { it.first }
                if (deltas.isNotEmpty()) append("\\n\\nSESSION REFERENCE DELTA (dB; current minus saved reference)\\n" +
                    deltas.joinToString("\\n") { "${it.first.toInt()} : ${"%.1f".format(Locale.US, it.second)}" })
            }
            append("\\n\\nUse identical phone placement for meaningful comparisons. Microphone AGC/noise suppression may still be active.")
        }
        results.text = all
    }

    private fun buildExport(): String {
        val l = averagedPoints("L")
        val r = averagedPoints("R")
        val chosen = when (exportMode) {
            "Left" -> l
            "Right" -> r
            else -> {
                if (l.isNotEmpty() && r.isNotEmpty()) l.zip(r).map { (a, b) -> CalPoint(a.hz, (a.db + b.db) / 2.0) }
                else if (l.isNotEmpty()) l else r
            }
        }
        require(chosen.size >= 2) { "Measure the selected channel before exporting." }
        return WaveletExporter.create(chosen)
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
