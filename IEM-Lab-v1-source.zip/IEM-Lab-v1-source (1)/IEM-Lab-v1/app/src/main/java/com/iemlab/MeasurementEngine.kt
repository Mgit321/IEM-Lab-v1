package com.iemlab

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.AudioManager
import android.media.AudioDeviceInfo
import android.content.Context
import kotlin.math.PI
import kotlin.math.sin

data class MeasurementPoint(val hz: Double, val db: Double, val channel: String, val run: Int)

class MeasurementEngine(private val context: Context) {
    private val sampleRate = 48000

    fun runChannel(channel: String, onPoint: (MeasurementPoint) -> Unit) {
        require(channel == "L" || channel == "R")
        val frequencies = Dsp.octaveFrequencies()
        frequencies.forEachIndexed { index, hz ->
            repeat(2) { run ->
                val point = captureTone(hz, channel, run + 1)
                onPoint(point)
                Thread.sleep(90)
            }
        }
    }

    private fun captureTone(hz: Double, channel: String, run: Int): MeasurementPoint {
        val minRecord = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val recordBuffer = maxOf(minRecord, 16384)
        val source = if (android.os.Build.VERSION.SDK_INT >= 24) {
            MediaRecorder.AudioSource.UNPROCESSED
        } else MediaRecorder.AudioSource.MIC

        var recorder: AudioRecord? = null
        var track: AudioTrack? = null
        try {
            recorder = AudioRecord(
                source, sampleRate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, recordBuffer
            )
            check(recorder.state == AudioRecord.STATE_INITIALIZED) { "Microphone could not be initialized." }

            val trackMin = AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(trackMin, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            recorder.startRecording()
            track.play()
            val frames = (sampleRate * 0.42).toInt()
            val pcm = ShortArray(frames * 2)
            val amplitude = 0.10
            for (i in 0 until frames) {
                val v = (sin(2.0 * PI * hz * i / sampleRate) * Short.MAX_VALUE * amplitude).toInt().toShort()
                if (channel == "L") {
                    pcm[i * 2] = v
                    pcm[i * 2 + 1] = 0
                } else {
                    pcm[i * 2] = 0
                    pcm[i * 2 + 1] = v
                }
            }
            var offset = 0
            while (offset < pcm.size) {
                val wrote = track.write(pcm, offset, pcm.size - offset)
                if (wrote <= 0) break
                offset += wrote
            }
            track.stop()

            val captured = ShortArray(16384)
            var total = 0
            while (total < captured.size) {
                val n = recorder.read(captured, total, captured.size - total)
                if (n <= 0) break
                total += n
            }
            val db = Dsp.goertzelDb(captured, total, sampleRate, hz)
            return MeasurementPoint(hz, db, channel, run)
        } finally {
            try { track?.release() } catch (_: Exception) {}
            try { recorder?.stop() } catch (_: Exception) {}
            try { recorder?.release() } catch (_: Exception) {}
        }
    }
}
