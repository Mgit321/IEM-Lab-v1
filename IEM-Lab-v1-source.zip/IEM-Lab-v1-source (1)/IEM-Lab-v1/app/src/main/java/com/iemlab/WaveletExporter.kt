package com.iemlab

import java.util.Locale
import kotlin.math.ln

object WaveletExporter {
    // Fixed 127-point grid documented by Wavelet. Do not alter or regenerate this grid.
    val frequencies = listOf(
        20,21,22,23,24,26,27,29,30,32,34,36,38,40,43,45,48,50,53,56,59,63,66,70,74,78,
        83,87,92,97,103,109,115,121,128,136,143,151,160,169,178,188,199,210,222,235,248,
        262,277,292,309,326,345,364,385,406,429,453,479,506,534,565,596,630,665,703,743,
        784,829,875,924,977,1032,1090,1151,1216,1284,1357,1433,1514,1599,1689,1784,1885,
        1991,2103,2221,2347,2479,2618,2766,2921,3086,3260,3443,3637,3842,4058,4287,4528,
        4783,5052,5337,5637,5955,6290,6644,7018,7414,7831,8272,8738,9230,9749,10298,10878,
        11490,12137,12821,13543,14305,15110,15961,16860,17809,18812,19871
    )

    fun create(measurements: List<CalPoint>, maxBoost: Double = 6.0): String {
        require(measurements.size >= 2) { "Run a measurement first." }
        val sorted = measurements.sortedBy { it.hz }
        val mean = sorted.map { it.db }.average()
        val gains = frequencies.map { hz ->
            val response = Dsp.interpolateLog(sorted, hz.toDouble())
            (mean - response).coerceIn(-maxBoost, maxBoost)
        }
        val peak = gains.maxOrNull() ?: 0.0
        val preamp = -peak.coerceAtLeast(0.0)
        val body = frequencies.zip(gains).joinToString("; ") { (f, g) ->
            "$f ${String.format(Locale.US, "%.1f", g)}"
        }
        return "GraphicEQ: $body\nPreamp: ${String.format(Locale.US, "%.1f", preamp)} dB\n"
    }
}
