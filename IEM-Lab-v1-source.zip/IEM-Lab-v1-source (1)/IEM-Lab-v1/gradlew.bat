@echo off
echo Gradle wrapper JAR is not included. Use the GitHub Actions workflow, which installs Gradle 8.10.2.
exit /b 1
